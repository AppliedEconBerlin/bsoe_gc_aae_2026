{smcl}
{* *! version 1.0 07may2026}{...}
{title:late_complier}

{pstd}
This is a Stata command for complier analysis in postestimation following OLS regressions using commands such as {cmd:regress} or {cmd:reghdfe}.

{pstd}
The conceptual motivation and methodological background are discussed in:
{browse "https://opus4.kobv.de/opus4-hsog/frontdoor/deliver/index/docId/6213/file/BSoE_DP_0095.pdf":Weinhardt (2026), Discussion Paper}.

{pstd}
The full ado package (including help files and example code) can be downloaded here:
{browse "https://www.dropbox.com/scl/fi/nr0o0h8frnfn6qqn5ipvc/late_complier.zip?rlkey=v3tf23zbdfh2cfpuibthw50du&dl=0":Download late_complier package (ZIP)}.

{title:Syntax}

{p 8 17 2}
{cmd:late_complier} {it:X1 X2 X3 ...} [{cmd:, graph}]

{title:Description}

{pstd}
{cmd:late_complier} performs postestimation complier-style variance decomposition following an OLS regression. The first variable {it:X1} is residualised using the current regression specification. The remaining variables {it:X2, X3, ...} define grouping structures (either binary or median-split groups).

{pstd}
The command quantifies how the residual variance of {it:X1} changes across these groups, thereby characterising how OLS implicitly reweights identifying variation under heterogeneous structures.

{title:Options}

{phang}
{cmd:graph} produces bar charts showing residual variance of {it:X1} across groups and variables.

{title:Example}

{phang}
{cmd:. sysuse auto, clear}

{phang}
{cmd:. reg price mpg weight foreign length turn}

{phang}
{cmd:. late_complier weight foreign mpg length turn}

{pstd}
In this example, the command reports how the residualised variation in {it:weight} differs across subgroups defined by {it:foreign}, {it:mpg}, {it:length}, and {it:turn}.

{pstd}
The {cmd:graph} option can be specified to visually examine the residualised variance across groups.

{title:Returned results}

{pstd}
The command returns a dataset containing:

{p2col 5 20 25 2}
{p2col:variable} grouping variable
{p2col:group_low} low group definition (0 or below median)
{p2col:group_high} high group definition (1 or above median)
{p2col:var_low} residual variance in low group
{p2col:var_high} residual variance in high group
{p2col:ratio} variance ratio (high/low)
{p_end}

{title:Author}

{pstd}
Felix Weinhardt