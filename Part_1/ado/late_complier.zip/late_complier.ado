capture program drop late_complier

program define late_complier, rclass
    version 18.0

    syntax varlist(min=2) [, GRAPH]

    preserve

    tokenize `varlist'
    local x "`1'"
    macro shift
    local Z "`*'"

    if "`e(cmd)'" == "" {
        di as err "no estimation results found (run regression first)"
        restore
        exit 301
    }

    tempvar esample
    gen byte `esample' = e(sample)

    local rhs "`e(rhs)'"

    * --------------------------------------------------
    * residualise X1
    * --------------------------------------------------
    tempvar xres
    quietly regress `x' `rhs' if `esample'
    quietly predict double `xres' if `esample', resid

    * --------------------------------------------------
    * storage
    * --------------------------------------------------
    tempfile results
    tempname posth

    postfile `posth' ///
        str20 variable ///
        str30 group_low ///
        str30 group_high ///
        double var_low ///
        double var_high ///
        double ratio ///
        using `results'

    * --------------------------------------------------
    * loop over grouping variables
    * --------------------------------------------------
    foreach z of local Z {

        quietly levelsof `z' if `esample', local(levels)
        local nlev : word count `levels'

        tempvar g

        * binary variable
        if `nlev' == 2 {

            gen byte `g' = `z' if `esample'

            quietly summarize `xres' if `g'==0 & `esample'
            local v0 = r(Var)

            quietly summarize `xres' if `g'==1 & `esample'
            local v1 = r(Var)

            post `posth' ///
                ("`z'") ("0") ("1") ///
                (`v0') (`v1') (`v1'/`v0')
        }

        * continuous → median split
        else {

            quietly summarize `z' if `esample', detail
            local med = r(p50)

            gen byte `g' = (`z' >= `med') if `esample'

            quietly summarize `xres' if `g'==0 & `esample'
            local v0 = r(Var)

            quietly summarize `xres' if `g'==1 & `esample'
            local v1 = r(Var)

            post `posth' ///
                ("`z'") ("below median") ("above median") ///
                (`v0') (`v1') (`v1'/`v0')
        }

        drop `g'
    }

    postclose `posth'
    use `results', clear

    * --------------------------------------------------
    * return results (IMPORTANT FOR PUBLISHABLE PACKAGE)
    * --------------------------------------------------
    gen double log_ratio = log(ratio)

    summarize ratio
    return scalar mean_ratio = r(mean)
    return scalar max_ratio  = r(max)
    return scalar min_ratio  = r(min)

    * --------------------------------------------------
    * TABLE OUTPUT
    * --------------------------------------------------
    di as text ""
    di as text "=================================================="
    di as text " Residual variance decomposition of `x'"
    di as text "=================================================="

    list variable group_low group_high var_low var_high ratio, clean noobs

    * --------------------------------------------------
    * GRAPH
    * --------------------------------------------------

if "`graph'" != "" {

    * =====================================================
    * WORK ON FROZEN ESTIMATION SAMPLE ONLY
    * =====================================================
    tempfile base low high

    save `base', replace

    * -----------------------------
    * LOW GROUP
    * -----------------------------
    use `base', clear
    keep variable group_low var_low
    gen group = group_low
    gen variance = var_low
    save `low', replace

    * -----------------------------
    * HIGH GROUP
    * -----------------------------
    use `base', clear
    keep variable group_high var_high
    gen group = group_high
    gen variance = var_high
    save `high', replace

    * -----------------------------
    * COMBINE
    * -----------------------------
    use `low', clear
    append using `high'

    sort variable group

    * -----------------------------
    * FINAL PLOT
    * -----------------------------
    graph bar variance, ///
        over(variable, label(angle(45))) ///
        over(group, label(angle(0))) ///
        bargap(40) ///
        ytitle("Residual variance of `x'") ///
        title("Identifying variation of `x' across covariates") ///
        legend(off)
}

    restore
end